import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.set.Set;

/**
 * JUnit test fixture for {@code Set<String>}'s constructor and kernel methods.
 *
 * @author Put your name here
 *
 */
public abstract class SetTest {

    /**
     * Invokes the appropriate {@code Set} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new set
     * @ensures constructorTest = {}
     */
    protected abstract Set<String> constructorTest();

    /**
     * Invokes the appropriate {@code Set} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new set
     * @ensures constructorRef = {}
     */
    protected abstract Set<String> constructorRef();

    /**
     * Creates and returns a {@code Set<String>} of the implementation under
     * test type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsTest = [entries in args]
     */
    private Set<String> createFromArgsTest(String... args) {
        Set<String> set = this.constructorTest();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    /**
     * Creates and returns a {@code Set<String>} of the reference implementation
     * type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsRef = [entries in args]
     */
    private Set<String> createFromArgsRef(String... args) {
        Set<String> set = this.constructorRef();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    // TODO - add test cases for constructor, add, remove, removeAny, contains, and size
    @Test
    public final void testNoArgumentConstructor() {
        /*
         * Set up variables and call method under test
         */
        Set<String> set = this.constructorTest();
        Set<String> setExpected = this.constructorRef();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(setExpected, set);
    }

    /*
     * Test cases for kernel methods
     */

    @Test
    public final void testAddEmpty() {
        /*
         * Set up variables
         */
        Set<String> set = this.createFromArgsTest();
        Set<String> setExpected = this.createFromArgsRef("red");
        /*
         * Call method under test
         */
        set.add("red");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(setExpected, set);
    }

    @Test
    public final void testAddNonEmptyOne() {
        /*
         * Set up variables
         */
        Set<String> set = this.createFromArgsTest("1");
        Set<String> setExpected = this.createFromArgsRef("1", "2");
        /*
         * Call method under test
         */
        set.add("2");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(setExpected, set);
    }

    @Test
    public final void testAddNonEmptyMoreThanOne() {
        /*
         * Set up variables
         */
        Set<String> set = this.createFromArgsTest("1", "2");
        Set<String> setExpected = this.createFromArgsRef("1", "2", "3");
        /*
         * Call method under test
         */
        set.add("3");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(setExpected, set);
    }

    @Test
    public final void testRemoveLeavingEmpty() {
        /*
         * Set up variables
         */
        Set<String> set = this.createFromArgsTest("red");
        Set<String> setExpected = this.createFromArgsRef();
        /*
         * Call method under test
         */
        String x = set.remove("red");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(setExpected, set);
        assertEquals("red", x);
    }

    @Test
    public final void testRemoveLeavingNonEmptyOne() {
        /*
         * Set up variables
         */
        Set<String> set = this.createFromArgsTest("1", "2");
        Set<String> setExpected = this.createFromArgsRef("1");
        /*
         * Call method under test
         */
        String x = set.remove("2");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(setExpected, set);
        assertEquals("2", x);
    }

    @Test
    public final void testRemoveLeavingNonEmptyMoreThanOne() {
        /*
         * Set up variables
         */
        Set<String> set = this.createFromArgsTest("1", "2", "3");
        Set<String> setExpected = this.createFromArgsRef("1", "3");
        /*
         * Call method under test
         */
        String x = set.remove("2");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(setExpected, set);
        assertEquals("2", x);
    }

    @Test
    public final void testSizeEmpty() {
        /*
         * Set up variables
         */
        Set<String> set = this.createFromArgsTest();
        Set<String> setExpected = this.createFromArgsRef();
        /*
         * Call method under test
         */
        int i = set.size();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(setExpected, set);
        assertEquals(0, i);
    }

    @Test
    public final void testSizeNonEmptyOne() {
        /*
         * Set up variables
         */
        Set<String> set = this.createFromArgsTest("1");
        Set<String> setExpected = this.createFromArgsRef("1");
        /*
         * Call method under test
         */
        int i = set.size();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(setExpected, set);
        assertEquals(1, i);
    }

    @Test
    public final void testSizeNonEmptyMoreThanOne() {
        /*
         * Set up variables
         */
        Set<String> set = this.createFromArgsTest("1", "2");
        Set<String> setExpected = this.createFromArgsRef("1", "2");
        /*
         * Call method under test
         */
        int i = set.size();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(setExpected, set);
        assertEquals(2, i);
    }

    @Test
    public final void testContainsEmpty() {
        /*
         * Set up variables
         */
        Set<String> set = this.createFromArgsTest();
        Set<String> setExpected = this.createFromArgsRef();
        /*
         * Call method under test
         */
        boolean check = set.contains("1");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(setExpected, set);
        assertTrue(!check);
    }

    @Test
    public final void testContainsNonEmptyTrueOne() {
        /*
         * Set up variables
         */
        Set<String> set = this.createFromArgsTest("1");
        Set<String> setExpected = this.createFromArgsRef("1");
        /*
         * Call method under test
         */
        boolean check = set.contains("1");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(setExpected, set);
        assertTrue(check);
    }

    @Test
    public final void testContainsNonEmptyFalseOne() {
        /*
         * Set up variables
         */
        Set<String> set = this.createFromArgsTest("1");
        Set<String> setExpected = this.createFromArgsRef("1");
        /*
         * Call method under test
         */
        boolean check = set.contains("3");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(setExpected, set);
        assertTrue(!check);
    }

    @Test
    public final void testContainsNonEmptyTrueMoreThanOne() {
        /*
         * Set up variables
         */
        Set<String> set = this.createFromArgsTest("1", "2");
        Set<String> setExpected = this.createFromArgsRef("1", "2");
        /*
         * Call method under test
         */
        boolean check = set.contains("2");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(setExpected, set);
        assertTrue(check);
    }

    @Test
    public final void testContainsNonEmptyFalseMoreThanOne() {
        /*
         * Set up variables
         */
        Set<String> set = this.createFromArgsTest("1", "2");
        Set<String> setExpected = this.createFromArgsRef("1", "2");
        /*
         * Call method under test
         */
        boolean check = set.contains("3");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(setExpected, set);
        assertTrue(!check);
    }

    @Test
    public final void testRemoveAnyLeavingEmpty() {
        /*
         * Set up variables
         */
        Set<String> set = this.createFromArgsTest("1");
        Set<String> setExpected = this.createFromArgsRef("1");
        /*
         * Call method under test
         */
        String x = set.removeAny();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(true, setExpected.contains(x));
        setExpected.remove(x);
        assertEquals(setExpected, set);
    }

    @Test
    public final void testRemoveAnyLeavingNonEmptyone() {
        /*
         * Set up variables
         */
        Set<String> set = this.createFromArgsTest("1", "2");
        Set<String> setExpected = this.createFromArgsRef("1", "2");
        /*
         * Call method under test
         */
        String x = set.removeAny();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(true, setExpected.contains(x));
        setExpected.remove(x);
        assertEquals(setExpected, set);
    }

    @Test
    public final void testRemoveAnyLeavingNonEmptyoneMoreThanOne() {
        /*
         * Set up variables
         */
        Set<String> set = this.createFromArgsTest("1", "2", "3");
        Set<String> setExpected = this.createFromArgsRef("1", "2", "3");
        /*
         * Call method under test
         */
        String x = set.removeAny();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(true, setExpected.contains(x));
        setExpected.remove(x);
        assertEquals(setExpected, set);
    }
}

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.map.Map;
import components.map.Map.Pair;

/**
 * JUnit test fixture for {@code Map<String, String>}'s constructor and kernel
 * methods.
 *
 * @author Put your name here
 *
 */
public abstract class MapTest {

    /**
     * Invokes the appropriate {@code Map} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new map
     * @ensures constructorTest = {}
     */
    protected abstract Map<String, String> constructorTest();

    /**
     * Invokes the appropriate {@code Map} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new map
     * @ensures constructorRef = {}
     */
    protected abstract Map<String, String> constructorRef();

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the implementation
     * under test type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsTest = [pairs in args]
     */
    private Map<String, String> createFromArgsTest(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorTest();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the reference
     * implementation type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsRef = [pairs in args]
     */
    private Map<String, String> createFromArgsRef(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorRef();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

// TODO - add test cases for constructor, add, remove, removeAny, value,
// hasKey, and size
    /*
     * Test cases for constructor
     */

    @Test
    public final void testNoArgumentConstructor() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> map = this.constructorTest();
        Map<String, String> mapExpected = this.constructorRef();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
    }

    /*
     * Test cases for kernel methods
     */
    @Test
    public final void testAddEmpty() {
        /*
         * Set up variables
         */
        Map<String, String> map = this.createFromArgsTest();
        Map<String, String> mapExpected = this.createFromArgsRef("A",
                "America");
        /*
         * Call method under test
         */
        map.add("A", "America");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
    }

    @Test
    public final void testAddNonemptyOne() {
        /*
         * Set up variables
         */
        Map<String, String> map = this.createFromArgsTest("A", "America");
        Map<String, String> mapExpected = this.createFromArgsRef("A", "America",
                "B", "Britain");
        /*
         * Call method under test
         */
        map.add("B", "Britain");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
    }

    @Test
    public final void testAddNonemptyMoreThanOne() {
        /*
         * Set up variables
         */
        Map<String, String> map = this.createFromArgsTest("A", "America", "B",
                "Britain");
        Map<String, String> mapExpected = this.createFromArgsRef("A", "America",
                "B", "Britain", "C", "China");
        /*
         * Call method under test
         */
        map.add("C", "China");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
    }

    @Test
    public final void testRemoveLeavingEmpty() {
        /*
         * Set up variables
         */
        Map<String, String> map = this.createFromArgsTest("A", "America");
        Map<String, String> mapExpected = this.createFromArgsRef();
        /*
         * Call method under test
         */
        Pair<String, String> out = map.remove("A");

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertEquals("A", out.key());
        assertEquals("America", out.value());

    }

    @Test
    public final void testRemoveLeavingNonemptyOne() {
        /*
         * Set up variables
         */
        Map<String, String> map = this.createFromArgsTest("A", "America", "B",
                "Britain");
        Map<String, String> mapExpected = this.createFromArgsRef("B",
                "Britain");
        /*
         * Call method under test
         */
        Pair<String, String> out = map.remove("A");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertEquals("A", out.key());
        assertEquals("America", out.value());

    }

    @Test
    public final void testRemoveLeavingNonemptyMoreThanOne() {
        /*
         * Set up variables
         */
        Map<String, String> map = this.createFromArgsTest("A", "America", "B",
                "Britain", "C", "China");
        Map<String, String> mapExpected = this.createFromArgsRef("B", "Britain",
                "C", "China");
        /*
         * Call method under test
         */
        Pair<String, String> out = map.remove("A");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertEquals("A", out.key());
        assertEquals("America", out.value());

    }

    @Test
    public final void testValueFromOne() {
        /*
         * Set up variables
         */
        Map<String, String> map = this.createFromArgsTest("A", "America");
        Map<String, String> mapExpected = this.createFromArgsRef("A",
                "America");
        /*
         * Call method under test
         */
        String val = map.value("A");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertEquals("America", val);
    }

    @Test
    public final void testValueFromMoreThanOne() {
        /*
         * Set up variables
         */
        Map<String, String> map = this.createFromArgsTest("A", "America", "B",
                "Britain");
        Map<String, String> mapExpected = this.createFromArgsRef("A", "America",
                "B", "Britain");
        /*
         * Call method under test
         */
        String val = map.value("A");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertEquals("America", val);
    }

    @Test
    public final void testHasKeyFromOneTrue() {
        /*
         * Set up variables
         */
        Map<String, String> map = this.createFromArgsTest("A", "America");
        Map<String, String> mapExpected = this.createFromArgsRef("A",
                "America");
        /*
         * Call method under test
         */
        Boolean hasK = map.hasKey("A");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertTrue(hasK);
    }

    @Test
    public final void testHasKeyFromOneFalse() {
        /*
         * Set up variables
         */
        Map<String, String> map = this.createFromArgsTest("A", "America");
        Map<String, String> mapExpected = this.createFromArgsRef("A",
                "America");
        /*
         * Call method under test
         */
        Boolean hasK = map.hasKey("B");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertTrue(!hasK);
    }

    @Test
    public final void testHasKeyFromMoreThanOneTrue() {
        /*
         * Set up variables
         */
        Map<String, String> map = this.createFromArgsTest("A", "America", "B",
                "Britain", "C", "China");
        Map<String, String> mapExpected = this.createFromArgsRef("A", "America",
                "B", "Britain", "C", "China");
        /*
         * Call method under test
         */
        Boolean hasK = map.hasKey("A");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertTrue(hasK);
    }

    @Test
    public final void testHasKeyFromMoreThanOneFalse() {
        /*
         * Set up variables
         */
        Map<String, String> map = this.createFromArgsTest("A", "America", "B",
                "Britain", "C", "China");
        Map<String, String> mapExpected = this.createFromArgsRef("A", "America",
                "B", "Britain", "C", "China");
        /*
         * Call method under test
         */
        Boolean hasK = map.hasKey("D");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertTrue(!hasK);
    }

    @Test
    public final void testRemoveAnyTwo() {
        /*
         * Set up variables
         */
        Map<String, String> map = this.createFromArgsTest("A", "America", "B",
                "Britain");
        Map<String, String> mapExpected = this.createFromArgsRef("A", "America",
                "B", "Britain");

        /*
         * Call method under test
         */
        Pair<String, String> p = map.removeAny();

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(true, mapExpected.hasKey(p.key()));
        mapExpected.remove(p.key());
        assertEquals(mapExpected, map);

    }

    @Test
    public final void testRemoveAnyMoreThanTwo() {
        /*
         * Set up variables
         */
        Map<String, String> map = this.createFromArgsTest("A", "America", "B",
                "Britain", "C", "China");
        Map<String, String> mapExpected = this.createFromArgsRef("A", "America",
                "B", "Britain", "C", "China");

        /*
         * Call method under test
         */
        Pair<String, String> p = map.removeAny();

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(true, mapExpected.hasKey(p.key()));
        mapExpected.remove(p.key());
        assertEquals(mapExpected, map);

    }

    @Test
    public final void testSizeEmpty() {
        /*
         * Set up variables
         */
        Map<String, String> map = this.createFromArgsTest();
        Map<String, String> mapExpected = this.createFromArgsRef();
        /*
         * Call method under test
         */
        int len = map.size();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertEquals(0, len);
    }

    @Test
    public final void testSizeNonemptyOne() {
        /*
         * Set up variables
         */
        Map<String, String> map = this.createFromArgsTest("A", "America");
        Map<String, String> mapExpected = this.createFromArgsRef("A",
                "America");
        /*
         * Call method under test
         */
        int len = map.size();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertEquals(1, len);
    }

    @Test
    public final void testSizeNonemptyMoreThanOne() {
        /*
         * Set up variables
         */
        Map<String, String> map = this.createFromArgsTest("A", "America", "B",
                "Britain", "C", "China");
        Map<String, String> mapExpected = this.createFromArgsRef("A", "America",
                "B", "Britain", "C", "China");
        /*
         * Call method under test
         */
        int len = map.size();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertEquals(3, len);
    }
}

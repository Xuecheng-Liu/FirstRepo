import java.util.Comparator;

import components.map.Map;
import components.map.Map1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.sortingmachine.SortingMachine;
import components.sortingmachine.SortingMachine1L;

/**
 * A program that generates a tag cloud HTML file based on the user's input text
 * file.
 *
 * @author Xuecheng Liu
 * @author Xinyue Li
 *
 */
public final class TagCloudGenerator {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private TagCloudGenerator() {
    }

    /**
     * SEPERATOR String.
     */
    private static final String SEPARATORS = " \t\n\r,-.!?[]';:/()";

    /**
     * Minimum font.
     */
    static final int MIN_FONT = 11;

    /**
     * Maximum font.
     */
    static final int MAX_FONT = 48;

    /**
     * String comparator.
     */
    private static class StringComparator
            implements Comparator<Map.Pair<String, Integer>> {
        @Override
        public int compare(Map.Pair<String, Integer> o1,
                Map.Pair<String, Integer> o2) {
            return o1.key().compareTo(o2.key());
        }
    }

    /**
     * Integer comparator.
     */
    private static class IntegerComparator
            implements Comparator<Map.Pair<String, Integer>> {
        @Override
        public int compare(Map.Pair<String, Integer> o1,
                Map.Pair<String, Integer> o2) {
            return o2.value().compareTo(o1.value());
        }
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */
    public static String nextWordOrSeparator(String text, int position) {
        assert text != null : "Violation of: text is not null";
        assert 0 <= position : "Violation of: 0 <= position";
        assert position < text.length() : "Violation of: position < |text|";

        // initialize the result
        String result = "";
        // situation where the character is contained in  SEPARATORS
        if (SEPARATORS.indexOf(text.charAt(position)) >= 0) {
            boolean flag = true;
            // extract the longest word where characters are in SEPARATORS
            for (int i = position; i < text.length() && flag; i++) {
                if (SEPARATORS.indexOf(text.charAt(i)) >= 0) {
                    result = text.substring(position, i + 1);
                } else {
                    flag = false;
                }
            }
        } else {
            boolean flag = true;
            //extract the longest word where all  characters are not in SEPARATORS
            for (int i = position; i < text.length() && flag; i++) {
                if (SEPARATORS.indexOf(text.charAt(i)) == -1) {
                    result = text.substring(position, i + 1);
                } else {
                    flag = false;
                }
            }
        }
        // return statement
        return result;
    }

    /**
     * Read through the file {@code inFile} line by line to update {@code pair}
     * with the non-separator tokens as key and corresponding counts as value.
     *
     * @param pair
     *            the map {@code pair} to be updated
     * @param inFile
     *            the file to read
     * @updates {@code pair}
     * @requires {@code pair} is not null and {@code inFile} is open
     * @ensures [the map is correctly updated based on the inFile]
     */
    public static void wordAndCount(Map<String, Integer> pair,
            SimpleReader inFile) {
        assert pair != null : "Violation of : map should not be null";
        assert inFile.isOpen() : "Violation of: simpleReader should be open";

        while (!inFile.atEOS()) {
            // read the file until the end of it
            String line = inFile.nextLine();
            int pos = 0;
            while (pos < line.length()) {
                // update the map if the token is not separator
                String token = nextWordOrSeparator(line, pos);
                if (SEPARATORS.indexOf(token.charAt(0)) == -1) {
                    token = token.toLowerCase();
                    if (pair.hasKey(token)) {
                        // update count
                        int count = pair.value(token);
                        count++;
                        pair.replaceValue(token, count);
                    } else {
                        // add the new word to the map with count equals 1
                        pair.add(token, 1);
                    }
                }
                // update the starting position of the next token in the line
                pos += token.length();
            }
        }
    }

    /**
     * return the values of largest and smallest counts in {@code pair} and sort
     * each pair in decreasing counts in {@code countBased} and the top N
     * {@code wordNumber} in {@code alphaBased} in alphabetic order.
     *
     * @param pair
     *            the map that contains are different words with respective
     *            count
     * @param wordNumber
     *            the number of word in tag cloud
     * @param countBased
     *            the sortingMachine that sorts pair in decreasing count order
     * @param alphaBased
     *            the sortingMachine that sort the top N words in alphabetic
     *            order
     * @updates countBased
     * @updates alphaBased
     * @return the array of max count and min count
     */
    public static int[] sortWord(Map<String, Integer> pair, int wordNumber,
            SortingMachine<Map.Pair<String, Integer>> countBased,
            SortingMachine<Map.Pair<String, Integer>> alphaBased) {
        assert pair != null : "Violation of: map cannot be null";
        assert countBased != null : "Violation of; sortingMachine cannot be null";
        assert alphaBased != null : "Violation of; sortingMachine cannot be null";

        /*
         * add each pair of the map to sortingMachine to sort based on counts
         */
        for (Map.Pair<String, Integer> each : pair) {
            countBased.add(each);
        }
        countBased.changeToExtractionMode();

        // update the wordNumber if it is greater than number of different words
        int size = countBased.size();
        if (size < wordNumber) {
            wordNumber = size;
        }

        // add the top N words from countBased to the alphaBased
        int[] maxAndMin = new int[2];
        for (int i = 0; i < wordNumber; i++) {
            Map.Pair<String, Integer> each = countBased.removeFirst();
            if (i == 0) {
                maxAndMin[1] = each.value();
            }
            if (i == wordNumber - 1) {
                maxAndMin[0] = each.value();
            }
            alphaBased.add(each);
        }
        //return statement
        return maxAndMin;
    }

    /**
     * Generate the HTML file named {@code fileName} based on the sortingMachine
     * {@code alphaBased} from the text file named {@code inName}.
     *
     * @param alphaBased
     *            the sortingMachine that contains top N pair in alphabetic
     *            order
     * @param fileName
     *            the output file name
     * @param input
     *            the input file name
     * @param min
     *            the minimum of the counts
     * @param max
     *            the maximum of the counts
     * @updates {@code alphaBased}
     * @ensures [the generated HTML page is well formatted and contains correct
     *          information]
     */
    public static void generateHTML(
            SortingMachine<Map.Pair<String, Integer>> alphaBased,
            String fileName, String input, int min, int max) {
        assert alphaBased != null : "Violation of: sortingMachine cannot be null";

        // initialize the SimpleWriter
        SimpleWriter out = new SimpleWriter1L(fileName);
        /*
         * write the header of the HTML page
         */
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Top " + alphaBased.size() + " words in " + input
                + "</title>");
        out.println(
                "<link href=\"http://web.cse.ohio-state.edu/software/2231/web-"
                        + "sw2/assignments/projects/tag-cloud-generator/data/tagcloud.css\""
                        + " rel=\"stylesheet\" type=\"text/css\">");
        out.println("</head>");
        out.println("<body>");
        out.println("<h2>Top " + alphaBased.size() + " words in " + input
                + "</h2>");
        out.println("<hr>");
        out.println("<div class=\"cdiv\">");
        out.println("<p class=\"cbox\">");

        /*
         * write the top N words in correct size
         */
        alphaBased.changeToExtractionMode();
        int size = alphaBased.size();
        while (alphaBased.size() > 0) {
            Map.Pair<String, Integer> pair = alphaBased.removeFirst();
            // evenly set the count of each word if max and min are the same
            int font = MIN_FONT + (MAX_FONT - MIN_FONT) / size;
            if (max != min) {
                // update the font based on the count if max and min differ
                font = (pair.value() - min) * (MAX_FONT - MIN_FONT)
                        / (max - min) + MIN_FONT;
            }
            out.println("<span style=\"cursor:default\" class=\"" + "f" + font
                    + "\" title=\"count: " + pair.value() + "\">" + pair.key()
                    + "</span>");
        }
        /*
         * write the close tag for the HTML file
         */
        out.println("</p>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
        // close the out stream
        out.close();
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        /*
         * initialize in and out streams
         */
        SimpleWriter out = new SimpleWriter1L();
        SimpleReader in = new SimpleReader1L();
        /*
         * ask for input file name, output file name and word count
         */
        out.print("Input file name: ");
        String input = in.nextLine();
        out.print("Output file name: ");
        String fileName = in.nextLine();
        out.print("Word count:  ");
        int wordNumber = in.nextInteger();

        /*
         * check validity of word count
         */
        while (wordNumber <= 0) {
            out.println("Word count should be positive");
            out.print("New word count: ");
            wordNumber = in.nextInteger();
        }

        /*
         * read the input file and generate the map with corresponding count
         */
        SimpleReader readFile = new SimpleReader1L(input);
        Map<String, Integer> pair = new Map1L<String, Integer>();
        wordAndCount(pair, readFile);

        /*
         * initialize the sortingMachines
         */
        SortingMachine<Map.Pair<String, Integer>> countBased = new SortingMachine1L<>(
                new IntegerComparator());
        SortingMachine<Map.Pair<String, Integer>> alphaBased = new SortingMachine1L<>(
                new StringComparator());
        /*
         * get the boundaries of the most N frequent words, and update the two
         * sorting machines with counts order and alphabetic order
         */
        int[] minAndMax = sortWord(pair, wordNumber, countBased, alphaBased);

        /*
         * generate the HTML page
         */
        generateHTML(alphaBased, fileName, input, minAndMax[0], minAndMax[1]);

        /*
         * close the input and output streams
         */
        readFile.close();
        in.close();
        out.close();
    }
}

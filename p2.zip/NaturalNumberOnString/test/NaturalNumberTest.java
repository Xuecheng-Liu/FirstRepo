import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.naturalnumber.NaturalNumber;

/**
 * JUnit test fixture for {@code NaturalNumber}'s constructors and kernel
 * methods.
 *
 * @author Xuecheng Liu, Xinyue Li
 *
 *
 */
public abstract class NaturalNumberTest {

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @return the new number
     * @ensures constructorTest = 0
     */
    protected abstract NaturalNumber constructorTest();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorTest = i
     */
    protected abstract NaturalNumber constructorTest(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorTest)
     */
    protected abstract NaturalNumber constructorTest(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorTest = n
     */
    protected abstract NaturalNumber constructorTest(NaturalNumber n);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @return the new number
     * @ensures constructorRef = 0
     */
    protected abstract NaturalNumber constructorRef();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorRef = i
     */
    protected abstract NaturalNumber constructorRef(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorRef)
     */
    protected abstract NaturalNumber constructorRef(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorRef = n
     */
    protected abstract NaturalNumber constructorRef(NaturalNumber n);

    // TODO - add test cases for four constructors, multiplyBy10, divideBy10, isZero

    /*
     * Test cases for four constructors
     */

    @Test
    public final void testNoArgumentConstructor() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber n = this.constructorTest();
        NaturalNumber nExpected = this.constructorRef();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    @Test
    public final void testNonzeroIntConstructor() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber n = this.constructorTest(123);
        NaturalNumber nExpected = this.constructorRef(123);
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    @Test
    public final void testZeroIntConstructor() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber n = this.constructorTest(0);
        NaturalNumber nExpected = this.constructorRef(0);
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    @Test
    public final void testNonzeroStringConstructor() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber n = this.constructorTest("123");
        NaturalNumber nExpected = this.constructorRef("123");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    @Test
    public final void testZeroStringConstructor() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber n = this.constructorTest("0");
        NaturalNumber nExpected = this.constructorRef("0");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    @Test
    public final void testNonzeroNaturalNumberConstructor() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber nExpected = this.constructorRef("123");
        NaturalNumber n = this.constructorTest(nExpected);

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    @Test
    public final void testZeroNaturalNumberConstructor() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber nExpected = this.constructorRef("0");
        NaturalNumber n = this.constructorTest(nExpected);

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /*
     * Test cases for multiplyBy10
     */
    @Test
    public final void testZeroMultiplyBy10PlusZero() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber n = this.constructorTest(0);
        NaturalNumber nExpected = this.constructorRef(0);
        /*
         * Call method under test
         */
        n.multiplyBy10(0);

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    @Test
    public final void testZeroMultiplyBy10PlusNonzero() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber n = this.constructorTest(0);
        NaturalNumber nExpected = this.constructorRef(8);
        /*
         * Call method under test
         */
        n.multiplyBy10(8);

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    @Test
    public final void testNonzeroMultiplyBy10PlusZero() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber n = this.constructorTest(111);
        NaturalNumber nExpected = this.constructorRef(1110);
        /*
         * Call method under test
         */
        n.multiplyBy10(0);

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    @Test
    public final void testNonzeroMultiplyBy10PlusNonzero() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber n = this.constructorTest(111);
        NaturalNumber nExpected = this.constructorRef(1115);
        /*
         * Call method under test
         */
        n.multiplyBy10(5);

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /*
     * Test cases for divideBy10
     */
    @Test
    public final void testNonzeroDivideBy10NonzeroRemainder() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber n = this.constructorTest(111);
        NaturalNumber nExpected = this.constructorRef(11);
        /*
         * Call method under test
         */
        int rem = n.divideBy10();

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(1, rem);
    }

    @Test
    public final void testNonzeroDivideBy10ZeroRemainder() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber n = this.constructorTest(800);
        NaturalNumber nExpected = this.constructorRef(80);
        /*
         * Call method under test
         */
        int rem = n.divideBy10();

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(0, rem);
    }

    @Test
    public final void testZeroDivideBy10() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber n = this.constructorTest(0);
        NaturalNumber nExpected = this.constructorRef(0);
        /*
         * Call method under test
         */
        int rem = n.divideBy10();

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(0, rem);
    }

    /*
     * Test cases for isZero
     */
    @Test
    public final void testZeroIsZero() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber n = this.constructorTest(0);
        NaturalNumber nExpected = this.constructorRef(0);
        /*
         * Call method under test
         */
        boolean check = n.isZero();

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(true, check);
    }

    @Test
    public final void testNonzeroIsZero() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber n = this.constructorTest(233);
        NaturalNumber nExpected = this.constructorRef(233);
        /*
         * Call method under test
         */
        boolean check = n.isZero();

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(false, check);
    }
}

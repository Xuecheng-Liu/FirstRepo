import java.util.Comparator;

import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * A program that generates a well-formatted HTML file contains all the words
 * and their count from the user's input text file.
 *
 * @author Xuecheng Liu
 */
public final class WordCounter {

    /**
     * Default constructor--private to prevent instantiation.
     */
    private WordCounter() {
        // no code needed here
    }

    /**
     * Compare {@code String}s in lexicographic order.
     */
    private static class StringLT implements Comparator<String> {
        @Override
        public int compare(String o1, String o2) {
            return o1.toLowerCase().compareTo(o2.toLowerCase());
        }
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */
    public static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        assert text != null : "Violation of: text is not null";
        assert separators != null : "Violation of: separators is not null";
        assert 0 <= position : "Violation of: 0 <= position";
        assert position < text.length() : "Violation of: position < |text|";

        // initialize the result
        String result = "";
        // situation where the character is contained in the set
        if (separators.contains(text.charAt(position))) {
            boolean flag = true;
            // extract the longest word where characters are in set
            for (int i = position; i < text.length() && flag; i++) {
                if (separators.contains(text.charAt(i))) {
                    result = text.substring(position, i + 1);
                } else {
                    flag = false;
                }
            }
        } else {
            boolean flag = true;
            //extract the longest word where all  characters are not in set
            for (int i = position; i < text.length() && flag; i++) {
                if (!separators.contains(text.charAt(i))) {
                    result = text.substring(position, i + 1);
                } else {
                    flag = false;
                }
            }
        }
        // return statement
        return result;
    }

    /**
     * Generates the set of characters in the given {@code String} into the
     * given {@code Set}.
     *
     * @param str
     *            the given {@code String}
     * @param strSet
     *            the {@code Set} to be replaced
     * @replaces strSet
     * @ensures strSet = entries(str)
     */
    public static void generateElements(String str, Set<Character> strSet) {
        assert str != null : "Violation of: str is not null";
        assert strSet != null : "Violation of: strSet is not null";

        // initialize tem Set
        Set<Character> tem = strSet.newInstance();
        // add characters of str into strSet
        if (str.length() > 0) {
            String sub = str.substring(1);
            generateElements(sub, tem);
            char first = str.charAt(0);
            if (!tem.contains(first)) {
                tem.add(first);
            }
        }
        // replace strSet
        strSet.transferFrom(tem);
    }

    /**
     * Generate the queue of sorted words in the given {@code Queue} from the
     * given set{@code Set}.
     *
     * @param words
     *            the given {@code Queue} to be updated
     * @param allWords
     *            the given {@code Set}
     * @updates words
     * @ensures [words is a queue contains all the elements in the set allWords]
     */
    public static void sortWord(Queue<String> words, Set<String> allWords) {
        assert words != null : "Violation of: words is not null";
        assert allWords != null : "Violation of: allWords is not null";

        /*
         * add the each element in the set to he queue
         */
        for (String word : allWords) {
            words.enqueue(word);
        }
        /*
         * sort the queue of terms in lexicographic order
         */
        Comparator<String> ci = new StringLT();
        words.sort(ci);
    }

    /**
     * Generate the HTML file named {@code outName} based on the queue of all
     * the words in {@code allWords} and the map of the each word with respect
     * to its count in {@code pairMap} from the text file named {@code inName}.
     *
     *
     *
     * @param inName
     *            the given {@code String}
     * @param outName
     *            the given {@code String}
     * @param allWords
     *            the given {@code Queue}
     * @param pairMap
     *            the given {@code Map}
     * @ensures [The generated HTML file is well-formatted which contains all
     *          the words with their counts in lexicographic order]
     */
    public static void outputHTML(String inName, String outName,
            Queue<String> allWords, Map<String, Integer> pairMap) {
        assert inName != null : "Violation of: inName is not null";
        assert inName != null : "Violation of: outName is not null";
        assert allWords != null : "Violation of: allWords is not null";
        assert pairMap != null : "Violation of: pairMap is not null";

        // open the stream to write the output file
        SimpleWriter output = new SimpleWriter1L(outName);
        /*
         * write the opening tags of the HTML file
         */
        output.println("<html>");
        output.println("<head>");
        output.println("<title>Words Counted in " + inName + " </title>");
        output.println("</head>");
        output.println("<body>");
        output.println("<h2>Words Counted in " + inName + " </h2>");
        output.println("<hr />");
        output.println("<table border=\"1\">");
        output.println("<tr>");
        output.println("<th>Words</th>");
        output.println("<th>Counts</th>");
        output.println("</tr>");
        /*
         * write the rows which show the words and their counts
         */
        for (String word : allWords) {
            output.println("<tr>");
            output.println("<th>" + word + "</th>");
            output.println("<th>" + pairMap.value(word) + "</th>");
            output.println("</tr>");
        }
        /*
         * write the closing tags for the output file
         */
        output.println("</table>");
        output.println("</body>");
        output.println("</html>");
        // close the output streams
        output.close();
    }

    /**
     * Generate the set of all the words in {@code Set} which is not separator
     * in {@code Set} and the words with their corresponding count in
     * {@code Map} from the text file named {@code String}.
     *
     * @param inName
     *            the given {@code String}
     *
     * @param allWords
     *            the given {@code Set} to be updated
     * @param separator
     *            the given {@code Set}
     * @param pairMap
     *            the given {@code Map} to be updated
     * @updates allWords
     * @updates pairMap
     * @ensures [allWords is a set contains all the words except separators in
     *          the text file] and [pairMap is a map contains all the words in
     *          the set allWords with their corresponding count]
     */
    public static void updateCount(String inName, Set<String> allWords,
            Set<Character> separator, Map<String, Integer> pairMap) {
        assert inName != null : "Violation of: inName is not null";
        assert allWords != null : "Violation of: allWords is not null";
        assert separator != null : "Violation of: separator is not null";
        assert pairMap != null : "Violation of: pairMap is not null";

        // open the stream for reading the file
        SimpleReader inFile = new SimpleReader1L(inName);
        /*
         * read the file line by line until the end of it
         */
        while (!inFile.atEOS()) {
            /*
             * initialize the variables
             */
            String line = inFile.nextLine();
            int position = 0;
            while (position < line.length()) {
                String token = nextWordOrSeparator(line, position, separator);
                //check whether token is a separator or not
                if (!separator.contains(token.charAt(0))) {
                    if (!allWords.contains(token)) {
                        //add token to the set and initialize the count to be
                        allWords.add(token);
                        pairMap.add(token, 1);
                    } else {
                        //update the count in the map
                        int count = pairMap.value(token);
                        pairMap.replaceValue(token, count + 1);
                    }
                }
                // update positions
                position += token.length();
            }
        }
        // close the inFile stream
        inFile.close();
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments; unused here
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        /*
         * prompt the user the enter the name of input file and output file
         */
        out.print("Enter the name of input file: ");
        String inName = in.nextLine();
        out.print("Enter the name of the output file: ");
        String outName = in.nextLine();
        /*
         * close the in and out streams
         */
        in.close();
        out.close();

        //initialize the set for separator and the string sep
        Set<Character> separator = new Set1L<Character>();
        final String sep = "\\\"\\'\\\\,.<>?~!@#$%^&*()_+= {}[]:;`";
        // generate a set of all the characters from the sep string into a set
        generateElements(sep, separator);

        /*
         * generate the set contains all the words in the input file and a map
         * contains all the words in the set with their corresponding counts
         */
        Set<String> allWords = new Set1L<String>();
        Map<String, Integer> pairMap = new Map1L<String, Integer>();
        updateCount(inName, allWords, separator, pairMap);

        // sort the queue of words in lexicographic order
        Queue<String> sorted = new Queue1L<String>();
        sortWord(sorted, allWords);

        //output the HTML file
        outputHTML(inName, outName, sorted, pairMap);
    }

}

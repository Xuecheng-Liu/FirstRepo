import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/**
 * A program that generates a tag cloud HTML file based on the user's input text
 * file.
 *
 * @author Xuecheng Liu
 * @author Xinyue Li
 *
 */
public final class TagCloudGeneratorStd {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private TagCloudGeneratorStd() {
    }

    /**
     * SEPERATOR String.
     */
    private static final String SEPARATORS = " \t\n\r,-.!?[]';:/()";

    /**
     * Minimum font.
     */
    static final int MIN_FONT = 11;

    /**
     * Maximum font.
     */
    static final int MAX_FONT = 48;

    /**
     * String comparator.
     */
    private static class StringComparator
            implements Comparator<java.util.Map.Entry<String, Integer>> {
        @Override
        public int compare(java.util.Map.Entry<String, Integer> o1,
                java.util.Map.Entry<String, Integer> o2) {
            return o1.getKey().compareTo(o2.getKey());
        }
    }

    /**
     * Integer comparator.
     */
    private static class IntegerComparator
            implements Comparator<java.util.Map.Entry<String, Integer>> {
        @Override
        public int compare(java.util.Map.Entry<String, Integer> o1,
                java.util.Map.Entry<String, Integer> o2) {
            return o2.getValue().compareTo(o1.getValue());
        }
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */
    public static String nextWordOrSeparator(String text, int position) {
        assert text != null : "Violation of: text is not null";
        assert 0 <= position : "Violation of: 0 <= position";
        assert position < text.length() : "Violation of: position < |text|";

        // initialize the result
        String result = "";
        // situation where the character is contained in  SEPARATORS
        if (SEPARATORS.indexOf(text.charAt(position)) >= 0) {
            boolean flag = true;
            // extract the longest word where characters are in SEPARATORS
            for (int i = position; i < text.length() && flag; i++) {
                if (SEPARATORS.indexOf(text.charAt(i)) >= 0) {
                    result = text.substring(position, i + 1);
                } else {
                    flag = false;
                }
            }
        } else {
            boolean flag = true;
            //extract the longest word where all  characters are not in SEPARATORS
            for (int i = position; i < text.length() && flag; i++) {
                if (SEPARATORS.indexOf(text.charAt(i)) == -1) {
                    result = text.substring(position, i + 1);
                } else {
                    flag = false;
                }
            }
        }
        // return statement
        return result;
    }

    /**
     * Read through the file {@code inFile} line by line to update {@code pair}
     * with the non-separator tokens as key and corresponding counts as value.
     *
     * @param pair
     *            the map {@code pair} to be updated
     * @param inFile
     *            the file to read
     * @updates {@code pair}
     * @requires {@code pair} is not null and {@code inFile} is open
     * @ensures [the map is correctly updated based on the inFile]
     */
    public static void wordAndCount(HashMap<String, Integer> pair,
            BufferedReader inFile) {
        assert pair != null : "Violation of : map should not be null";

        String line = null;
        try {
            line = inFile.readLine();
            while (line != null) {
                int pos = 0;
                while (pos < line.length()) {
                    // update the map if the token is not separator
                    String token = nextWordOrSeparator(line, pos);
                    if (SEPARATORS.indexOf(token.charAt(0)) == -1) {
                        token = token.toLowerCase();
                        if (pair.containsKey(token)) {
                            // update count
                            int count = pair.get(token);
                            count++;
                            pair.replace(token, count);
                        } else {
                            // add the new word to the map with count equals 1
                            pair.put(token, 1);
                        }
                    }
                    // update the starting position of the next token in the line
                    pos += token.length();
                }
                line = inFile.readLine();
            }
        } catch (IOException e) {
            System.err.println("Error reading the file");
        }
    }

    /**
     * return the values of largest and smallest counts in {@code pair} and sort
     * each pair in decreasing counts in {@code countBased} and the top N
     * {@code wordNumber} in {@code alphaBased} in alphabetic order.
     *
     * @param pair
     *            the map that contains are different words with respective
     *            count
     * @param wordNumber
     *            the number of word in tag cloud
     * @param countBased
     *            the list that sorts pair in decreasing count order
     * @param alphaBased
     *            the list that sort the top N words in alphabetic order
     * @updates countBased
     * @updates alphaBased
     * @return the array of max count and min count
     */
    public static int[] sortWord(HashMap<String, Integer> pair, int wordNumber,
            List<HashMap.Entry<String, Integer>> countBased,
            List<HashMap.Entry<String, Integer>> alphaBased) {
        assert pair != null : "Violation of: map cannot be null";
        assert countBased != null : "Violation of: list cannot be null";
        assert alphaBased != null : "Violation of: list cannot be null";

        /*
         * add each pair of the map to sortingMachine to sort based on counts
         */
        Set<Map.Entry<String, Integer>> entries = pair.entrySet();
        for (Map.Entry<String, Integer> entry : entries) {
            countBased.add(entry);
        }
        countBased.sort(new IntegerComparator());

        // update bound if it is greater than number of different words
        int size = countBased.size();
        int bound = wordNumber;
        if (size < wordNumber) {
            bound = size;
        }
        // add the top N words from countBased to the alphaBased
        int[] minAndMax = new int[2];
        for (int i = 0; i < bound; i++) {
            Map.Entry<String, Integer> each = countBased.get(i);
            if (i == 0) {
                minAndMax[1] = each.getValue();
            }
            if (i == bound - 1) {
                minAndMax[0] = each.getValue();
            }
            alphaBased.add(each);
        }
        alphaBased.sort(new StringComparator());
        return minAndMax;
    }

    /**
     * Generate the HTML file named {@code fileName} based on the sortingMachine
     * {@code alphaBased} from the text file named {@code inName}.
     *
     * @param alphaBased
     *            the sortingMachine that contains top N pair in alphabetic
     *            order
     * @param outFileName
     *            the output file name
     * @param inFileName
     *            the input file name
     * @param min
     *            the minimum of the counts
     * @param max
     *            the maximum of the counts
     * @updates {@code alphaBased}
     * @ensures [the generated HTML page is well formatted and contains correct
     *          information]
     */
    public static void generateHTML(List<Map.Entry<String, Integer>> alphaBased,
            String outFileName, String inFileName, int min, int max) {
        assert alphaBased != null : "Violation of: list cannot be null";

        PrintWriter out;
        try {
            out = new PrintWriter(
                    new BufferedWriter(new FileWriter(outFileName)));
            /*
             * write the header of the HTML page
             */
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Top " + alphaBased.size() + " words in "
                    + inFileName + "</title>");
            out.println(
                    "<link href=\"http://web.cse.ohio-state.edu/software/2231/web-"
                            + "sw2/assignments/projects/tag-cloud-generator/data/tagcloud.css\""
                            + " rel=\"stylesheet\" type=\"text/css\">");
            out.println("</head>");
            out.println("<body>");
            out.println("<h2>Top " + alphaBased.size() + " words in "
                    + inFileName + "</h2>");
            out.println("<hr>");
            out.println("<div class=\"cdiv\">");
            out.println("<p class=\"cbox\">");

            /*
             * write the top N words in correct size
             */
            int size = alphaBased.size();
            for (int i = 0; i < size; i++) {
                Map.Entry<String, Integer> pair = alphaBased.remove(0);
                // evenly set the count of each word if max and min are the same
                int font = MIN_FONT + (MAX_FONT - MIN_FONT) / size;
                if (max != min) {
                    // update the font based on the count if max and min differ
                    font = (pair.getValue() - min) * (MAX_FONT - MIN_FONT)
                            / (max - min) + MIN_FONT;
                }
                out.println("<span style=\"cursor:default\" class=\"" + "f"
                        + font + "\" title=\"count: " + pair.getValue() + "\">"
                        + pair.getKey() + "</span>");
            }
            /*
             * write the close tag for the HTML file
             */
            out.println("</p>");
            out.println("</div>");
            out.println("</body>");
            out.println("</html>");
            /*
             * close the file
             */
            out.close();
        } catch (IOException e) {
            System.err.println("Error writing on to file");
        }
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        /*
         * initialize the scanner and ask for input/output file name, and word
         * count
         */
        Scanner in = new Scanner(System.in);
        System.out.print("Input file name: ");
        String inFileName = in.nextLine();
        System.out.print("Output file name: ");
        String outFileName = in.nextLine();
        System.out.print("Word count: ");
        int wordCount = in.nextInt();

        /*
         * check validity of word count
         */
        while (wordCount <= 0) {
            System.out.println("Word count should be positive");
            System.out.print("New word count: ");
            wordCount = in.nextInt();
        }
        /*
         * close the scanner
         */
        in.close();
        /*
         * read the input file and generate the map with corresponding count
         */
        BufferedReader readFile;
        try {
            readFile = new BufferedReader(new FileReader(inFileName));
            HashMap<String, Integer> pair = new HashMap<String, Integer>();
            wordAndCount(pair, readFile);
            /*
             * initialize the lists
             */
            List<Map.Entry<String, Integer>> countBased = new ArrayList<>();
            List<Map.Entry<String, Integer>> alphaBased = new ArrayList<>();
            /*
             * update the lists and get min count and max count
             */
            int[] minAndMax = sortWord(pair, wordCount, countBased, alphaBased);

            /*
             * generate HTML file
             */
            generateHTML(alphaBased, outFileName, inFileName, minAndMax[0],
                    minAndMax[1]);
        } catch (IOException e) {
            System.err.println("Error opening file");
            return;
        }
        try {
            readFile.close();
        } catch (IOException e) {
            System.err.println("Error closing file");
        }
    }
}
